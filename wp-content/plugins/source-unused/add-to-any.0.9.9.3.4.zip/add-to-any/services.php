<?php

$A2A_SHARE_SAVE_services = Array(

	"aim" => Array(
		"name" => "AIM",
		"icon" => "aim",
	),
	"aol_mail" => Array(
		"name" => "AOL Mail",
		"icon" => "aol",
	),
	"allvoices" => Array(
		"name" => "Allvoices",
		"icon" => "allvoices",
	),
	"amazon_wish_list" => Array(
		"name" => "Amazon Wish List",
		"icon" => "amazon",
	),
	"arto" => Array(
		"name" => "Arto",
		"icon" => "arto",
	),
	"ask.com_mystuff" => Array(
		"name" => "Ask.com MyStuff",
		"icon" => "ask",
	),
	"backflip" => Array(
		"name" => "Backflip",
		"icon" => "backflip",
	),
	"bebo" => Array(
		"name" => "Bebo",
		"icon" => "bebo",
	),
	"bibsonomy" => Array(
		"name" => "BibSonomy",
		"icon" => "bibsonomy",
	),
	"bitty_browser" => Array(
		"name" => "Bitty Browser",
		"icon" => "bitty",
	),
	"blinklist" => Array(
		"name" => "Blinklist",
		"icon" => "blinklist",
	),
	"blogmarks" => Array(
		"name" => "BlogMarks",
		"icon" => "blogmarks",
	),
	"blogger_post" => Array(
		"name" => "Blogger Post",
		"icon" => "blogger",
	),
	"bookmarks.fr" => Array(
		"name" => "Bookmarks.fr",
		"icon" => "bookmarks_fr",
	),
	"buddymarks" => Array(
		"name" => "BuddyMarks",
		"icon" => "buddymarks",
	),
	"buzzster" => Array(
		"name" => "Buzzster",
		"icon" => "bzzster",
	),
	"care2_news" => Array(
		"name" => "Care2 News",
		"icon" => "care2",
	),
	"citeulike" => Array(
		"name" => "CiteULike",
		"icon" => "citeulike",
	),
	"connotea" => Array(
		"name" => "Connotea",
		"icon" => "connotea",
	),
	"current" => Array(
		"name" => "Current",
		"icon" => "current",
	),
	"dzone" => Array(
		"name" => "DZone",
		"icon" => "dzone",
	),
	"delicious" => Array(
		"name" => "Delicious",
		"icon" => "delicious",
	),
	"design_float" => Array(
		"name" => "Design Float",
		"icon" => "designfloat",
	),
	"digg" => Array(
		"name" => "Digg",
		"icon" => "digg",
	),
	"diglog" => Array(
		"name" => "Diglog",
		"icon" => "diglog",
	),
	"diigo" => Array(
		"name" => "Diigo",
		"icon" => "diigo",
	),
	"evernote" => Array(
		"name" => "Evernote",
		"icon" => "evernote",
	),
	"expression" => Array(
		"name" => "Expression",
		"icon" => "expression",
	),
	"facebook" => Array(
		"name" => "Facebook",
		"icon" => "facebook",
	),
	"fark" => Array(
		"name" => "Fark",
		"icon" => "fark",
	),
	"faves" => Array(
		"name" => "Faves",
		"icon" => "faves",
	),
	"folkd" => Array(
		"name" => "Folkd",
		"icon" => "folkd",
	),
	"foxiewire" => Array(
		"name" => "Foxiewire",
		"icon" => "foxiewire",
	),
	"friendfeed" => Array(
		"name" => "FriendFeed",
		"icon" => "friendfeed",
	),
	"funp" => Array(
		"name" => "FunP",
		"icon" => "funp",
	),
	"furl" => Array(
		"name" => "Furl",
		"icon" => "furl",
	),
	"gabbr" => Array(
		"name" => "Gabbr",
		"icon" => "gabbr",
	),
	"global_grind" => Array(
		"name" => "Global Grind",
		"icon" => "global_grind",
	),
	"gmail" => Array(
		"name" => "Gmail",
		"icon" => "gmail",
	),
	"google_bookmarks" => Array(
		"name" => "Google Bookmarks",
		"icon" => "google",
	),
	"health_ranker" => Array(
		"name" => "Health Ranker",
		"icon" => "healthranker",
	),
	"hellotxt" => Array(
		"name" => "HelloTxt",
		"icon" => "hellotxt",
	),
	"hemidemi" => Array(
		"name" => "Hemidemi",
		"icon" => "hemidemi",
	),
	"hotmail" => Array(
		"name" => "Hotmail",
		"icon" => "live",
	),
	"hugg" => Array(
		"name" => "Hugg",
		"icon" => "hugg",
	),
	"hyves" => Array(
		"name" => "Hyves",
		"icon" => "hyves",
	),
	"identi.ca" => Array(
		"name" => "Identi.ca",
		"icon" => "identica",
	),
	"imera_brazil" => Array(
		"name" => "Imera Brazil",
		"icon" => "imera",
	),
	"instapaper" => Array(
		"name" => "Instapaper",
		"icon" => "instapaper",
	),
	"jamespot" => Array(
		"name" => "Jamespot",
		"icon" => "jamespot",
	),
	"jumptags" => Array(
		"name" => "Jumptags",
		"icon" => "jumptags",
	),
	"khabbr" => Array(
		"name" => "Khabbr",
		"icon" => "khabbr",
	),
	"kledy" => Array(
		"name" => "Kledy",
		"icon" => "kledy",
	),
	"linkagogo" => Array(
		"name" => "LinkaGoGo",
		"icon" => "linkagogo",
	),
	"linkatopia" => Array(
		"name" => "Linkatopia",
		"icon" => "linkatopia",
	),
	"linkedin" => Array(
		"name" => "LinkedIn",
		"icon" => "linkedin",
	),
	"livejournal" => Array(
		"name" => "LiveJournal",
		"icon" => "livejournal",
	),
	"msdn" => Array(
		"name" => "MSDN",
		"icon" => "msdn",
	),
	"maple" => Array(
		"name" => "Maple",
		"icon" => "maple",
	),
	"meneame" => Array(
		"name" => "Meneame",
		"icon" => "meneame",
	),
	"mindbodygreen" => Array(
		"name" => "MindBodyGreen",
		"icon" => "mindbodygreen",
	),
	"mister-wong" => Array(
		"name" => "Mister-Wong",
		"icon" => "mister-wong",
	),
	"mixx" => Array(
		"name" => "Mixx",
		"icon" => "mixx",
	),
	"multiply" => Array(
		"name" => "Multiply",
		"icon" => "multiply",
	),
	"mylinkvault" => Array(
		"name" => "MyLinkVault",
		"icon" => "mylinkvault",
	),
	"myspace" => Array(
		"name" => "MySpace",
		"icon" => "myspace",
	),
	"netlog" => Array(
		"name" => "Netlog",
		"icon" => "netlog",
	),
	"netvibes_share" => Array(
		"name" => "Netvibes Share",
		"icon" => "netvibes",
	),
	"netvouz" => Array(
		"name" => "Netvouz",
		"icon" => "netvouz",
	),
	"newsvine" => Array(
		"name" => "NewsVine",
		"icon" => "newsvine",
	),
	"nowpublic" => Array(
		"name" => "NowPublic",
		"icon" => "nowpublic",
	),
	"oneview" => Array(
		"name" => "Oneview",
		"icon" => "oneview",
	),
	"phonefavs" => Array(
		"name" => "PhoneFavs",
		"icon" => "phonefavs",
	),
	"ping" => Array(
		"name" => "Ping",
		"icon" => "ping",
	),
	"plaxo_pulse" => Array(
		"name" => "Plaxo Pulse",
		"icon" => "plaxo",
	),
	"propeller" => Array(
		"name" => "Propeller",
		"icon" => "propeller",
	),
	"protopage_bookmarks" => Array(
		"name" => "Protopage Bookmarks",
		"icon" => "protopage",
	),
	"pusha" => Array(
		"name" => "Pusha",
		"icon" => "pusha",
	),
	"reddit" => Array(
		"name" => "Reddit",
		"icon" => "reddit",
	),
	"segnalo" => Array(
		"name" => "Segnalo",
		"icon" => "segnalo",
	),
	"shoutwire" => Array(
		"name" => "Shoutwire",
		"icon" => "shoutwire",
	),
	"simpy" => Array(
		"name" => "Simpy",
		"icon" => "simpy",
	),
	"sitejot" => Array(
		"name" => "SiteJot",
		"icon" => "sitejot",
	),
	"slashdot" => Array(
		"name" => "Slashdot",
		"icon" => "slashdot",
	),
	"smaknews" => Array(
		"name" => "SmakNews",
		"icon" => "smaknews",
	),
	"sphere" => Array(
		"name" => "Sphere",
		"icon" => "sphere",
	),
	"sphinn" => Array(
		"name" => "Sphinn",
		"icon" => "sphinn",
	),
	"spurl" => Array(
		"name" => "Spurl",
		"icon" => "spurl",
	),
	"squidoo" => Array(
		"name" => "Squidoo",
		"icon" => "squidoo",
	),
	"startaid" => Array(
		"name" => "StartAid",
		"icon" => "startaid",
	),
	"strands" => Array(
		"name" => "Strands",
		"icon" => "strands",
	),
	"stumbleupon" => Array(
		"name" => "StumbleUpon",
		"icon" => "stumbleupon",
	),
	"stumpedia" => Array(
		"name" => "Stumpedia",
		"icon" => "stumpedia",
	),
	"symbaloo_feeds" => Array(
		"name" => "Symbaloo Feeds",
		"icon" => "symbaloo",
	),
	"taggly" => Array(
		"name" => "Taggly",
		"icon" => "taggly",
	),
	"tagza" => Array(
		"name" => "Tagza",
		"icon" => "tagza",
	),
	"tailrank" => Array(
		"name" => "Tailrank",
		"icon" => "tailrank",
	),
	"technet" => Array(
		"name" => "TechNet",
		"icon" => "technet",
	),
	"technorati_favorites" => Array(
		"name" => "Technorati Favorites",
		"icon" => "technorati",
	),
	"technotizie" => Array(
		"name" => "Technotizie",
		"icon" => "technotizie",
	),
	"tipd" => Array(
		"name" => "Tipd",
		"icon" => "tipd",
	),
	"tumblr" => Array(
		"name" => "Tumblr",
		"icon" => "tumblr",
	),
	"twiddla" => Array(
		"name" => "Twiddla",
		"icon" => "twiddla",
	),
	"twitter" => Array(
		"name" => "Twitter",
		"icon" => "twitter",
	),
	"typepad_post" => Array(
		"name" => "TypePad Post",
		"icon" => "typepad",
	),
	"viadeo" => Array(
		"name" => "Viadeo",
		"icon" => "viadeo",
	),
	"webnews" => Array(
		"name" => "Webnews",
		"icon" => "webnews",
	),
	"windows_live_favorites" => Array(
		"name" => "Windows Live Favorites",
		"icon" => "live",
	),
	"windows_live_spaces" => Array(
		"name" => "Windows Live Spaces",
		"icon" => "spaces",
	),
	"wink" => Array(
		"name" => "Wink",
		"icon" => "wink",
	),
	"wists" => Array(
		"name" => "Wists",
		"icon" => "wists",
	),
	"xerpi" => Array(
		"name" => "Xerpi",
		"icon" => "xerpi",
	),
	"yahoo_bookmarks" => Array(
		"name" => "Yahoo Bookmarks",
		"icon" => "yahoo",
	),
	"yahoo_buzz" => Array(
		"name" => "Yahoo Buzz",
		"icon" => "buzz",
	),
	"yahoo_mail" => Array(
		"name" => "Yahoo Mail",
		"icon" => "yahoo",
	),
	"yahoo_messenger" => Array(
		"name" => "Yahoo Messenger",
		"icon" => "yim",
	),
	"yample" => Array(
		"name" => "Yample",
		"icon" => "yample",
	),
	"yigg" => Array(
		"name" => "YiGG",
		"icon" => "yigg",
	),
	"yoolink" => Array(
		"name" => "Yoolink",
		"icon" => "yoolink",
	),
	"youmob" => Array(
		"name" => "YouMob",
		"icon" => "youmob",
	),
	"unalog" => Array(
		"name" => "unalog",
		"icon" => "unalog",
	),

);